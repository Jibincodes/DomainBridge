# Domain Bridge — Complete Interactive Prototype (Updated Dashboard)

This is a self-contained, **offline-capable** prototype of the six-screen Domain Bridge academic-to-professional journey. Screen 1 now features the professor-inspired aspirational **future Technology Consultant** image banner. All other screens and their interactions are retained.

## Quick start (no coding or installation)

1. Download **Domain_Bridge_Complete_Prototype.zip**.
2. Extract the ZIP (do not open `index.html` from inside the compressed archive).
3. Open the extracted **Domain_Bridge_Complete_Prototype** folder.
4. Double-click **index.html**. It opens in Chrome, Edge, Firefox or Safari.
5. Explore the six sections using the left navigation.

**Keep the `assets` folder next to `index.html`.** The welcome-banner photo is stored at `assets/sameh_future_consultant.jpg`. If the image does not appear, check that the ZIP was extracted and the folder structure was preserved.

No npm, Python, server, internet connection, FHNW account, or installation is required. If your browser restricts local file access, see the optional local server method below.

## Online access with GitHub Pages (optional)

1. Create a GitHub repository, e.g. `domain-bridge-prototype`.
2. Upload the **contents of the extracted folder** to the repository root: `index.html`, `README.md`, `START_HERE.txt`, and the entire `assets/` directory.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose **main** and **/(root)**, then Save.
5. When deployment completes, GitHub Pages will show your site URL. Include it in the report. For a private class demo, be aware that standard GitHub Pages sites may be publicly accessible.

**Pushing files to GitHub alone does not publish a website.** GitHub Pages must be enabled separately. Because the app is static HTML/CSS/JavaScript, no build command is required.

## What is interactive?

| Screen | Working interactions |
|---|---|
| 1. Dashboard | New image-led future visualization, editable career preference, curriculum recommendation, links to other screens |
| 2. My Capability Journey | Clickable capability nodes, connections, source/evidence detail, link to learning |
| 3. Learning Bridge | Business-to-SQL mapping, learning perspective choices, reporting consequence comparison |
| 4. Workbench | Editable SQL, Run/Reset, local evaluator, optional graduated hints, saved explanations, transfer exercise |
| 5. Competency Evidence | Evidence changes with activities, “Why do we say this?” explanations, downloadable JSON |
| 6. Practice Lab | Four sequential phases, simulated stakeholder Q&A, written deliverables, completion and portfolio export |
| Settings | Demo transparency, data export, reset |

### Demonstration tip

Start on the Dashboard, use **View My Capability Journey**, follow the highlighted SQL Joins connection, open **Learning Bridge**, then **Workbench**. Run the deliberately flawed SQL and change `ON c.region = o.sales_region` to `ON c.customer_id = o.customer_id`. Check the updated **Competency Evidence**, then explore the **Practice Lab**.

## Prototype boundaries

- This is a **research and design demonstration**, not an FHNW product or a live integration.
- The future image is **AI-generated and aspirational**, not a photograph of the actual student or a prediction of employment.
- Academic context, curriculum, client, and stakeholder are fictional/illustrative; no real FHNW records are accessed.
- The Practice Lab stakeholder replies are **scripted offline simulations**, not responses from a live AI model.
- The SQL evaluator supports a restricted reporting query pattern, **not arbitrary SQL**.
- The application saves progress in the browser's `localStorage` where available. It does not send activity to a server.
- Evidence of an activity is not proof of independent mastery, job readiness, or real client experience.

## Optional local server

If your browser refuses to load local assets, open a terminal in the extracted folder and run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000/` in a browser. Python is **not** required for the normal double-click method.

## Included files

```
Domain_Bridge_Complete_Prototype/
├── index.html                       Main interactive app
├── assets/
│   └── sameh_future_consultant.jpg   New dashboard banner artwork
├── README.md                        Full setup, features, limitations
└── START_HERE.txt                   One-minute instructions
```
